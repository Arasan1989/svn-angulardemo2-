﻿import { Component , OnInit } from "@angular/core"
import { IEmployee } from './employee'
import { EmployeeService } from './employee.service'


@Component({
    selector: 'my-employeeList',
    templateUrl: 'app/employee/employeeList.component.html',
    styleUrls: ['app/employee/employeeList.component.css']
   
})

export class EmployeeListComponent implements OnInit {
    employees: IEmployee[];
    statusMessage:string ='Loading Date.Please Wait...';
    selectedEmployeeCountRadioButton: string = "All";

    //constructor(){
    //this.employees = [
    //    { code: 'emp1', name: 'tom', gender: 'Male', annualSalary: 1000.10 ,dateOfBirth:'10/10/2018'},
    //    { code: 'emp2', name: 'ram', gender: 'Male', annualSalary: 2000,dateOfBirth: '5/10/2018' },
    //    { code: 'emp3', name: 'tina', gender: 'Female', annualSalary: 3000.950, dateOfBirth: '1/2/2018' },
    //    { code: 'emp4', name: 'gracy', gender: 'Female', annualSalary: 4000, dateOfBirth: '11/26/2018' },
    //    { code: 'emp5', name: 'tony', gender: 'Male', annualSalary: 5000, dateOfBirth: '11/02/2018' } 
    //    ]
    //}

    constructor(private _employeeService: EmployeeService) { }

    //ngOnInit() {
    //    this._employeeService.getEmployees().subscribe((employeeData) => this.employees = employeeData);
    //}

    ngOnInit() {
        this._employeeService.getEmployees().subscribe((employeeData) => this.employees = employeeData,
            (error) => { this.statusMessage = 'Problem with the service.Please try again after soemtime'; });
    }

    onEmployeeCountRadioButtonChange(selectedRadioButtonValue: string): void {
        this.selectedEmployeeCountRadioButton = selectedRadioButtonValue;
    }
    getTotalEmployeesCount(): number {
        return this.employees.length;
    }

    getMaleEmployeesCount(): number {
        return this.employees.filter(e => e.gender === "Male").length;
    }

    getFemaleEmployeesCount(): number {
        return this.employees.filter(e => e.gender === "Female").length;
    }

    //getEmployees(): void {
    //    this.employees=[
    //        { code: 'emp1', name: 'tom', gender: 'Male', annualSalary: 1000.10, dateOfBirth: '10/10/2018' },
    //        { code: 'emp2', name: 'ram', gender: 'Male', annualSalary: 2000, dateOfBirth: '5/10/2018' },
    //        { code: 'emp3', name: 'tina', gender: 'Female', annualSalary: 3000.950, dateOfBirth: '1/2/2018' },
    //        { code: 'emp4', name: 'gracy', gender: 'Female', annualSalary: 4000, dateOfBirth: '11/26/2018' },
    //        { code: 'emp5', name: 'tony', gender: 'Male', annualSalary: 5000, dateOfBirth: '11/02/2018' }
    //    ]
    //}

    trackByEmpCode(index: number, employee: any): string {
        return employee.code;
    }
}