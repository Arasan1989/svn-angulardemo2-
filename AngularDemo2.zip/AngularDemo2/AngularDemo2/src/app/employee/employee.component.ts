﻿import { Component } from "@angular/core"
import { IEmployee } from "./employee"
import { ActivatedRoute } from '@angular/router'
import { EmployeeService } from './employee.service'
import 'rxjs/add/operator/retry'
import { ISubscription } from 'rxjs/Subscription'

@Component({
    selector : 'my-employee',
    templateUrl: 'app/employee/employee.component.html',
    styleUrls : ['app/employee/employee.component.css']
})

export class EmployeeComponent {
    employee: IEmployee;
    statusMessage: string;
    retryCount: number = 5;
    subscription: ISubscription;
    constructor(private _employeeService: EmployeeService, private _activatedRoute: ActivatedRoute) {
    }
    ngOnInit() {
        let employeeCode: string = this._activatedRoute.snapshot.params['code'];
        this.subscription = this._employeeService.getEmployeeBycode(employeeCode).retryWhen((err) => {
            return err.scan((retryCount, val) => {
                retryCount = retryCount + 1;
                if (retryCount < 6) {
                }
                else { throw (err) }
            }, 0).delay(1000)
        }).subscribe(
            (employeeData) => this.employee = employeeData,
            (error) => {
                this.statusMessage = "Problem with service";
                console.log(error);
            });
        //this._employeeService.getEmployeeBycode(employeeCode).then(
        //    (employeeData) => this.employee = employeeData,
        //    (error) => {
        //        this.statusMessage = "Problem with the service";
        //        console.log(error);
        //    }
        //);
        this.subscription.unsubscribe();
    }
    
}