﻿
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core'
@Component({
    selector: 'simple',
    template: ` Your entered: {{simpleInput}}
                Your entered: {{simpleInput1}}
                `
})

export class SimpleComponent implements OnChanges
{
    @Input() simpleInput: string;

    @Input() simpleInput1: string;

    ngOnChanges(changes: SimpleChanges) {
        for (let propertyName in changes) {
            let change = changes[propertyName];
            let currentValue = JSON.stringify(change.currentValue);
            let previousValue = JSON.stringify(change.previousValue);
            //console.log(propertyName + " :Currentvalue: " + currentValue + " , " + "Previousvalue: " + previousValue);
            console.log(`${propertyName} : currentValue =${currentValue},previousValue=${previousValue}`);
            }
    }
}