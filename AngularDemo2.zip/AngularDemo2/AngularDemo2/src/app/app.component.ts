import { Component } from "@angular/core";
@Component({
    selector: 'my-app',
    //template: `
    //               <div>
    //                     <h1 > {{'Page Header: ' +pageHeader}}</h1> 
    //                       <h2>{{getFullName()}}</h2>
    //                     <h3>{{pageFooter ? pageFooter : 'No Footer'}} </h3>
    //                       <img src='{{imagePath}}' />
    //                       <img [src]='imagePath' />
    //                           <br>
    //                        <button bind-disabled='isDisabled'>Click Me! </button>
    //                        <span [innerHtml] ='pageBody'></span>
    //                        <div [innerHtml]='badHtml'></div>
    //                     <my-employee></my-employee>
    //               </div>
    //`

    //template:   `
    //               <div>
    //                <input type='text' id='inputId' value ='Tom'>
    //                </div>
    //            `

//    template: `<button class="boldClass" [class]="colorCss">Click Me!</button>
//                <button class="boldClass italicclass colorCss" [class.boldClass]="!applyboldClass">Click Now!</button>
//                <br/><br/>
//                <button class="colorCss" [ngClass]="addClasses()">Click ngclasses!</button>
//                <br/><br/>
//                <button style='color:red' [ngStyle]='addStyles()'> Click Style! </button>
        
//                 <button (click)='onClick()'> Click Event1</button>
//                <my-employee></my-employee>

//<br/>
//<br/>`

//    template: `<input [value]='firstName' (input)='firstName=$event.target.value' />
//<br/>
//<input [(ngModel)]='firstName' />
//<br/>
//you entered : {{firstName}}`

    //template: `<my-employeeList> </my-employeeList>`


    //ngonchnages
    //template: `Your Text: <input type='text'  [(ngModel)] ='userText'/>
    //            <br/><br/>
    //        <simple [simpleInput]='userText' [simpleInput1]='userText'></simple>
            //`

    template: `<div style="padding:5px"> 
                <ul class = "nav nav-tabs">
                    <li routerLinkActive ="active" >
                          <a routerLink="home" > Home </a>
                    </li>
                       <li routerLinkActive ="active" >
                          <a routerLink="employee" > Employee </a>
                    </li>
                    <br>
                    <router-outlet></router-outlet>
                </ul>
               </div>`

})
export class AppComponent {
    pageHeader: string = "Employee Details";
    pageFooter: string = "Footer";
    pageBody: string = "Body";
    imagePath: string = "http://www.pragimtech.com/Images/Logo.JPG";
    isDisabled: boolean = true;
    badHtml: string = 'Hello <script>alert("hacked");</script> World';

    colorCss: string = "italicClass colorClass";
    applyboldClass: boolean = true;
    applyItalicClass: boolean = true;
    fontSize: number = 30;

    firstName: string = "Raj";
    lastName: string = "Kumar";
    getFullName() {
        return this.firstName +' '+ this.lastName;
    }
    addClasses()
    {
        let classses = {
            boldClass: this.applyboldClass,
            italicclass: this.applyItalicClass
        };
        return classses;
    }
    addStyles(){
        let styles = {
            'font-size.px': this.fontSize,
            'font-style': this.applyItalicClass ? 'italic' : 'normal',
            'font-weight': this.applyboldClass ? 'bold':'normal'
        }
        return styles;
    }
    onClick(): void {
        console.log('Event Button Clicked!');
    }

    //ngonchnages
    userText: string = 'Hello';
}