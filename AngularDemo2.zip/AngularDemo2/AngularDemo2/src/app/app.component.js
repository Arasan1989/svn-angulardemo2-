"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.pageHeader = "Employee Details";
        this.pageFooter = "Footer";
        this.pageBody = "Body";
        this.imagePath = "http://www.pragimtech.com/Images/Logo.JPG";
        this.isDisabled = true;
        this.badHtml = 'Hello <script>alert("hacked");</script> World';
        this.colorCss = "italicClass colorClass";
        this.applyboldClass = true;
        this.applyItalicClass = true;
        this.fontSize = 30;
        this.firstName = "Raj";
        this.lastName = "Kumar";
        //ngonchnages
        this.userText = 'Hello';
    }
    AppComponent.prototype.getFullName = function () {
        return this.firstName + ' ' + this.lastName;
    };
    AppComponent.prototype.addClasses = function () {
        var classses = {
            boldClass: this.applyboldClass,
            italicclass: this.applyItalicClass
        };
        return classses;
    };
    AppComponent.prototype.addStyles = function () {
        var styles = {
            'font-size.px': this.fontSize,
            'font-style': this.applyItalicClass ? 'italic' : 'normal',
            'font-weight': this.applyboldClass ? 'bold' : 'normal'
        };
        return styles;
    };
    AppComponent.prototype.onClick = function () {
        console.log('Event Button Clicked!');
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            //template: `
            //               <div>
            //                     <h1 > {{'Page Header: ' +pageHeader}}</h1> 
            //                       <h2>{{getFullName()}}</h2>
            //                     <h3>{{pageFooter ? pageFooter : 'No Footer'}} </h3>
            //                       <img src='{{imagePath}}' />
            //                       <img [src]='imagePath' />
            //                           <br>
            //                        <button bind-disabled='isDisabled'>Click Me! </button>
            //                        <span [innerHtml] ='pageBody'></span>
            //                        <div [innerHtml]='badHtml'></div>
            //                     <my-employee></my-employee>
            //               </div>
            //`
            //template:   `
            //               <div>
            //                <input type='text' id='inputId' value ='Tom'>
            //                </div>
            //            `
            //    template: `<button class="boldClass" [class]="colorCss">Click Me!</button>
            //                <button class="boldClass italicclass colorCss" [class.boldClass]="!applyboldClass">Click Now!</button>
            //                <br/><br/>
            //                <button class="colorCss" [ngClass]="addClasses()">Click ngclasses!</button>
            //                <br/><br/>
            //                <button style='color:red' [ngStyle]='addStyles()'> Click Style! </button>
            //                 <button (click)='onClick()'> Click Event1</button>
            //                <my-employee></my-employee>
            //<br/>
            //<br/>`
            //    template: `<input [value]='firstName' (input)='firstName=$event.target.value' />
            //<br/>
            //<input [(ngModel)]='firstName' />
            //<br/>
            //you entered : {{firstName}}`
            //template: `<my-employeeList> </my-employeeList>`
            //ngonchnages
            //template: `Your Text: <input type='text'  [(ngModel)] ='userText'/>
            //            <br/><br/>
            //        <simple [simpleInput]='userText' [simpleInput1]='userText'></simple>
            //`
            template: "<div style=\"padding:5px\"> \n                <ul class = \"nav nav-tabs\">\n                    <li routerLinkActive =\"active\" >\n                          <a routerLink=\"home\" > Home </a>\n                    </li>\n                       <li routerLinkActive =\"active\" >\n                          <a routerLink=\"employee\" > Employee </a>\n                    </li>\n                    <br>\n                    <router-outlet></router-outlet>\n                </ul>\n               </div>"
        })
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map