﻿import { Component } from '@angular/core'

@Component({
template : ` <h1> the requested page not found </h1>`
})
export class PageNotFoundComponent {
}