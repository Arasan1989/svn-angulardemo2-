﻿import { Component } from '@angular/core'
@Component(
    {
        template:`<h1> Welcome to Home page</h1>`
    }
)
export class HomeComponent {
}